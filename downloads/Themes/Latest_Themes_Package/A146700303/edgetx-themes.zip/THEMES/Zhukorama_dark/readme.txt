Thank you for choosing this topic. It is made in white blue and red color.

Kirill Blokhin Coffemansky
@ZhukoRamaFPVlog
