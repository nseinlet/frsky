Thank you for using my theme! It's made primarily red and gray to match my TX16S MAX with the silver faceplate, and red anodized parts. It has blue highlights to match the blue power LED on the radio as well. Included is a background image taken from my infamous Skyhunter flying high above the clouds. The backgroud image is washed over so the important info shows over the top of it well, and the background image stays just there, in the background. :) Enjoy!

-Keith Luneau
www.youtube.com/bonafidepirate

Thanks to the EdgeTX team for the awesome radio firmware, and to OpenTX that it's built on!