Thanks to everyone who liked my theme!
The goal of this theme is to provide a rich, vivid and harmonious color experience. 

- Curious <https://curious.host>