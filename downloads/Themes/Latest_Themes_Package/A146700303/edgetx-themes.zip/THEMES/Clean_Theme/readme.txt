This is the most minimalistic, clean theme I could think up that makes sense to me. No embellishments, just a clean theme.

Author: Mate Soos
License: Public Domain (i.e. anything can be done with it)
