A dark theme with high contrast.

Author: Justin Wasilenko
License: Public Domain (i.e. anything can be done with it)
