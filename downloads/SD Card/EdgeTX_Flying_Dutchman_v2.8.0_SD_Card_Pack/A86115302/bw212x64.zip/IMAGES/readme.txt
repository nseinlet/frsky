You can put your model BMP and other graphic files in this directory.
BMP color depth must be set to 4 bits.
