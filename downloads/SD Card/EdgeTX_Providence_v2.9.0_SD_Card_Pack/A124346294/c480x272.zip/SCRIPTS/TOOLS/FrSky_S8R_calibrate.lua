-- TNS|FrSky S8R/S6R Calibrate|TNE

local function run()
    return "/SCRIPTS/TOOLS/FrSky_S8R_S6R/S8R_calibrate.lua"
end

return { run = run }
