-- TNS|Flights History v1.1|TNE

local function run()
    return "/SCRIPTS/TOOLS/FlightsHistory/main.lua"
end

return { run = run }
